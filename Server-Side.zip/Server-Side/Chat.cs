﻿/*  This class functions as the controller
*
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace Websocket_Server
{
    class Chat : WebSocketBehavior
    {
        private Database db = new Database();

        protected override void OnOpen()
        {
            //Send each user in the conversation a message stating "Chat between X and Y"
        }

        protected override void OnMessage(MessageEventArgs e)
        {

            /* TO DO:   Allow multiple sessions
            *           Ensure messages are sent to the correct parties
            *           Add actions for the CMD Switchcase
            *           Remember users as UNIQUE sessions
            */



            // Retrieve message from client
            string msg = e.Data;

            string[] cmd = msg.Split(':');              //Pulls the CMD from the rest of he
            if (cmd.Length > 2)                         //Checks if there was more than one colon
            {
                for (int x = 2; x < cmd.Length; x++)    //Mashes the extra elements together
                {
                    cmd[1] = cmd[1] + ":" + cmd[x];
                }
            }

            switch (cmd[0])
            {
                case "LOGIN":           //Expecting "LOGIN: USERNAME PASSWORD" Return contacts "!USER, ~USER, ..."  
                    //Send info to Program                    // ! - Online, ~ - Offline
                    break;
                case "LOGOUT":          //Expecting "LOGOUT: USERNAME" *Disconnect user*
                    //Send info to Program
                    break;
                case "ADDFRIEND":       //Expecting "ADDFRIEND: USERNAME CONTACT"
                    //Send info to Program
                    break;
                case "REMOVEFRIEND":    //Expecting "ADDFRIEND: USERNAME CONTACT"
                    //Send info to Program
                    break;
                case "CONNECT":         //Expecting "CONNECT: USERNAME CONTACT"
                    //Send info to Program
                    break;
                case "MSG":             //Expecting "MSG: (Insert Text)"
                    //Broadcast Message to both parties in a conversation
                    break;                   

            }                        

            // Broadcast message to all clients
            Sessions.Broadcast(msg);
        }
    }
}
