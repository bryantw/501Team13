﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Websocket_Server
{
    class Database
    {
        private Dictionary<string, Account> allAccounts = new Dictionary<string, Account>(); //Stores all accounts of the database using the Username of accounts as a key
        
        /* Parameter(s): The username of the account, The password of the account
        * Creates a new Account object and stores it in allAccounts
        */
        public bool createUser(String name, String password)
        {
            try
            {
                if (allAccounts.ContainsKey(name))
                {
                    return false;       //Ensures no duplicate Usernames
                }
                Account temp = new Account(password);
                allAccounts.Add(name, temp);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the account, The password of the account
        * Asks the Account object to verify the account password
        */
        public bool logIn(String name, String password)
        {
            try
            {
                return allAccounts[name].verifyAccount(password);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the requester, The requested contact 
        * Calls the Account of the user to add the contact to their "contacts" list
        */
        public bool addContact(String name, String contact)
        {
            try
            {
                return allAccounts[name].addContact(contact);
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
