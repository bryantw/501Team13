﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Websocket_Server
{
    class Account
    {
        private String password;
        private List<String> contacts;      //Contact List of user
        public bool online;                 //Whether or not the user is online

        public Account(string n)
        {
            password = n;
            online = true;
            contacts = new List<String>();         
        }

        /* Parameter(s): The string given as a password
        * Ensures that the password is correct
        */
        public bool verifyAccount(String p)
        {
            if (p.Equals(password))
            {
                return true;
            }
            return false;
        }

        /* Parameter(s): Name of contact to be added
        * Adds another user to this user's contact list
        */
        public bool addContact(String p)
        {
            try {
                contacts.Add(p);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): Name of contact to be removed
        * Removes the requested user from this user's contact list
        */
        public bool removeContact(String p)
        {
            try
            {
                contacts.Remove(p);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
