﻿/*  This class functions as the controller
*
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace Websocket_Server
{
    class Chat : WebSocketBehavior
    {
        private Database db = new Database();
        List<Tuple<string, string>> sessionIDs = new List<Tuple<string, string>>();  //Session ID, Username

        protected override void OnOpen()
        {            
                    //Events that occur when a new client opens
        }

        protected override void OnMessage(MessageEventArgs e)
        {

            /* TO DO:   Allow multiple sessions
            *           Ensure messages are sent to the correct parties
            *           Add actions for the CMD Switchcase
            *           Remember users as UNIQUE sessions
            */                        

            // Retrieve message from client
            string msg = e.Data;

            string[] cmd = msg.Split(':');                  //Pulls the CMD from the rest of he
            if (cmd.Length > 2)                             //Checks if there was more than one colon
            {
                for (int x = 2; x < cmd.Length; x++)        //Mashes the extra elements together
                {
                    cmd[1] = cmd[1] + ":" + cmd[x];
                }
            }
            string[] info;
            switch (cmd[0])
            {
                case "LOGIN":                               //Expecting "LOGIN: USERNAME PASSWORD" Return contacts "!USER, ~USER, ..."  (! - Online, ~ - Offline)
                    info = cmd[1].Split(' ');               //(info[0] - Username, info[1] - Password)
                    if (db.accountExists(info[0]))
                    {
                        if (db.logIn(info[0], info[1]))
                        {
                            Send("Welcome back, " + info[0]);
                        }
                        else
                        {
                            Send("Log In unsucessful");
                        }
                    }
                    else
                    {
                        if (db.createUser(info[0], info[1]))
                        {
                            Send("Welcome to Chat, " + info[0]);
                        }
                        else
                        {
                            Send("Account name taken");
                        }
                        
                    }
                    break;
                case "LOGOUT":                              //Expecting "LOGOUT: USERNAME" *Disconnect user*
                    info = cmd[1].Split(' ');
                    db.logOut(info[0]);
                    break;
                case "ADDFRIEND":                           //Expecting "ADDFRIEND: USERNAME CONTACT"
                    info = cmd[1].Split(' ');
                    if (db.addContact(info[0], info[1]))
                    {
                        Send("Contact added");
                    }
                    else
                    {
                        Send("Unable to add contact");
                    }
                    break;
                case "REMOVEFRIEND":                        //Expecting "ADDFRIEND: USERNAME CONTACT"
                    info = cmd[1].Split(' ');
                    if (db.removeContact(info[0], info[1]))
                    {
                        Send("Contact removed");
                    }                     
                    else
                    {
                        Send("Error or contact does not exist");
                    }
                    break;
                case "CONNECT":         //Expecting "CONNECT: USERNAME CONTACT"
                    //Connect the broadcasting of both users
                    break;
                case "DISCONNECT":         //Expecting "CONNECT: USERNAME CONTACT"
                    //Remove the broadcasting connections between the users
                    break;
                case "MSG":             //Expecting "MSG: (Insert Text)"
                    //Broadcast Message to both parties in a conversation
                    break;                   

            }                        

            // Broadcast message to all clients
            Sessions.Broadcast(msg);
        }
    }
}
