﻿/*  This class functions as the controller
*
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace Websocket_Server
{
    class Chat : WebSocketBehavior
    {
        private Database db = new Database();
        Dictionary<string, string> usersToSessions = new Dictionary<string, string>();      //A dictionary that associates each Username to its respective session ID
        Dictionary<string, string> sessionsToUsers = new Dictionary<string, string>();      //A dictionary that associates each Session ID to its respective Username
        List<List<String>> conversations = new List<List<String>>();                        //Holds a list of lists that each contain users currently chatting between eachother

        protected override void OnOpen()
        {
            //Events that occur when a new client opens                        
        }

        protected override void OnMessage(MessageEventArgs e)
        {            
            /* TO DO:   DISCUSS WITH CLIENT-SIDE ABOUT CONTACT LISTS
            */                        

            // Retrieve message from client
            string msg = e.Data;

            string[] cmd = msg.Split(':');                  //Pulls the CMD from the rest of he
            if (cmd.Length > 2)                             //Checks if there was more than one colon
            {
                for (int x = 2; x < cmd.Length; x++)        //Mashes the extra elements together
                {
                    cmd[1] = cmd[1] + ":" + cmd[x];
                }
            }
            string[] info;
            switch (cmd[0])
            {
                case "LOGIN":                               //Expecting "LOGIN: USERNAME PASSWORD" Return contacts "!USER, ~USER, ..."  (! - Online, ~ - Offline)
                    info = cmd[1].Split(' ');               //(info[0] - Username, info[1] - Password)
                    if (db.accountExists(info[0]))
                    {
                        if (db.logIn(info[0], info[1]))
                        {
                            Send("Welcome back, " + info[0]);
                            usersToSessions.Add(this.ID, info[0]);
                            sessionsToUsers.Add(info[0], this.ID);
                        }
                        else
                        {
                            Send("Log In unsucessful");
                        }
                    }
                    else                                    //User needs an account
                    {
                        if (db.createUser(info[0], info[1]))
                        {
                            Send("Welcome to Chat, " + info[0]);
                            usersToSessions.Add(info[0], this.ID);
                            sessionsToUsers.Add(info[0], this.ID);
                        }
                        else
                        {
                            Send("Account name taken");
                        }
                        
                    }
                    break;
                case "LOGOUT":                              //Expecting "LOGOUT: USERNAME" *Disconnect user*
                    info = cmd[1].Split(' ');
                    db.logOut(info[0]);
                    break;
                case "ADDFRIEND":                           //Expecting "ADDFRIEND: USERNAME CONTACT"
                    info = cmd[1].Split(' ');
                    if (db.addContact(info[0], info[1]))
                    {
                        Send("Contact added");
                    }
                    else
                    {
                        Send("Unable to add contact");
                    }
                    break;
                case "REMOVEFRIEND":                        //Expecting "ADDFRIEND: USERNAME CONTACT"
                    info = cmd[1].Split(' ');
                    if (db.removeContact(info[0], info[1]))
                    {
                        Send("Contact removed");
                    }                     
                    else
                    {
                        Send("Error or contact does not exist");
                    }
                    break;
                case "CONNECT":         //Expecting "CONNECT: USERNAME CONTACT"
                    info = cmd[1].Split(' ');
                    if (db.inConversation(info[1]))                     //If the requested contact is in a conversation, then they cannot be added
                    {
                        Send("Error: Your contact are currently in a conversation");
                        break;
                    }                    
                    foreach (List<string> s in conversations)           //If the requesting user is in any conversation, then their contact is added to it
                    {
                        if (s.Contains(info[0]))
                        {
                            s.Add(info[1]);
                            db.addedToConvo(info[1]);
                            break;
                        }                        
                    }
                    List<string> newConvo = new List<string>();         //Both users are not within conversations, so we create a new conversation containing each of them
                    newConvo.Add(info[0]);
                    newConvo.Add(info[1]);
                    conversations.Add(newConvo);
                    db.addedToConvo(info[0]);
                    db.addedToConvo(info[1]);
                    break;
                case "DISCONNECT":         //Expecting "DISCONNECT: USERNAME"
                    string name = cmd[1];
                    foreach (List<string> s in conversations)
                    {
                        if (s.Contains(name))
                        {                            
                            db.removedFromConvo(name);
                            s.Remove(name);
                            if (s.Count == 1)
                            {
                                foreach (string x in s)
                                {
                                    db.removedFromConvo(x);                                    
                                }
                                conversations.Remove(s);
                            }                            
                        }
                    }
                    break;
                case "MSG":             //Expecting "MSG: USERNAME (Insert Text)"                    
                    foreach (List<string> s in conversations)
                    {
                        if (s.Contains(sessionsToUsers[this.ID]))                       //If the requesting user is in a conversation
                        {                           
                            foreach (string x in s)                                     //Send his/her message to each user in the conversation
                            {
                                Sessions.SendTo(usersToSessions[x], cmd[1]);
                            }
                        }
                    }                    
                    break;                   

            }                        

            // Broadcast message to all clients
            Sessions.Broadcast(msg);
        }
    }
}
