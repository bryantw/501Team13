﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Websocket_Server
{
    class Database
    {
        private Dictionary<string, Account> allAccounts = new Dictionary<string, Account>(); //Stores all accounts of the database using the Username of accounts as a key
        
        /* Parameter(s): The username of the account, The password of the account
        * Creates a new Account object and stores it in allAccounts
        */
        public bool createUser(string name, string password)
        {
            try
            {
                if (allAccounts.ContainsKey(name))
                {
                    return false;       //Ensures no duplicate Usernames
                }
                Account temp = new Account(password);
                allAccounts.Add(name, temp);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the account
        * Determines if an account with the given "name" exists
        */
        public bool accountExists(string name)
        {
            if (allAccounts.ContainsKey(name))
            {
                return true;
            }
            return false;
        }

        /* Parameter(s): The username of the account, The password of the account
        * Asks the Account object to verify the account password
        */
        public bool logIn(string name, string password)
        {
            try
            {
                return allAccounts[name].verifyAccount(password);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the account
        * Sets the account status to "offline"
        */
        public void logOut(string name)
        {
            allAccounts[name].online = false;
        }

        /* Parameter(s): The username of the requester, The requested contact 
        * Calls the Account of the user to add the contact to their "contacts" list
        */
        public bool addContact(string name, string contact)
        {
            try
            {
                return allAccounts[name].addContact(contact);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the requester, the contact to be removed
        * Calls the Account of the user and removes the contact from their "contacts" list
        */
        public bool removeContact(string name, string contact)
        {
            try
            {
                return allAccounts[name].removeContact(contact);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /* Parameter(s): The username of the account
        * Returns true if the user is in a conversation
        */
        public bool inConversation(string name)
        {
            return allAccounts[name].inConversation;
        }

        /* Parameter(s): The username of the account
        * Changes an account's "inConvo" status to true
        */
        public void addedToConvo(string name)
        {
            allAccounts[name].inConversation = true;
        }

        /* Parameter(s): The username of the account
        * Changes an account's "inConvo" status to false
        */
        public void removedFromConvo(string name)
        {
            allAccounts[name].inConversation = false;
        }
    }
}
