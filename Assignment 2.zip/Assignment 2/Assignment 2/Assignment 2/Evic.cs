﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Evic
    {
            //System Status Options
        public int oilChange;       //Selecting will reset to 3000 mi
        public int odometer;

            //Warning Messages
        public bool doorAjar;
        public bool checkEngine;
        public bool oilNeedsChanged;

            //Personal Settings
        public bool metricUnits;

            //Temperature Info
        public int tempOutside;
        public int tempInside;

            //Trip Information
        public int tripA;
        public int tripB;

        public Evic(int oil, int odo, bool door, bool eng, bool change, bool metric, int tempOut, int tempIn, int A, int B)
        {
            oilChange = oil;
            odometer = odo;
            doorAjar = door;
            checkEngine = eng;
            oilNeedsChanged = change;
            metricUnits = metric;
            tempOutside = tempOut;
            tempInside = tempIn;
            tripA = A;
            tripB = B;
        }

        public void changeUnits()
        {
            if (metricUnits == false) //change from mi to km
            {
                oilChange = (int)(oilChange * 1.60934);
                odometer = (int)(odometer * 1.60934);
                tripA = (int)(tripA * 1.60934);
                tripB = (int)(tripB * 1.60934);
                metricUnits = true;
            }
            else                    //change from km to mi
            {
                oilChange = (int)(oilChange * 0.621371);
                odometer = (int)(odometer * 0.621371);
                tripA = (int)(tripA * 0.621371);
                tripB = (int)(tripB * 0.621371);
                metricUnits = false;
            }
        }
    }
}
