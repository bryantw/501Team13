﻿/* Assignment 2
 * Authors: Team 13 (Daniel, Cody, Bryant)
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Program
    {
        private static Evic sys = new Evic(1566, 33546, true, false, false, false, 148, 130, 385, 100);
        /*
         * This method starts the program by running the DisplaySystemStatus Method 
         */
        public static void Main(string[] args)
        {
            DisplaySystemStatus();
        }
        /*
         * this method will display the mileage on the odometer and the distance till oil change, and switch to other menus with the left and right keys
         * 
         */
        public static void DisplaySystemStatus()
        {
            Console.WriteLine("\nSystem Status\n(For simulator: press Q)");
	        bool isMile = true;
	        bool con = true;
	        do
	        {
		        if (isMile)
		        {
			        DisplayMileage();
		        }
		        else
		        {
                    if (sys.metricUnits)
                    {
                        Console.WriteLine("Oil change in " + sys.oilChange + " km");
                    }
                    else
                    {
                        Console.WriteLine("Oil change in " + sys.oilChange + " mi");
                    }
		        }
		        ConsoleKeyInfo Key = Console.ReadKey(true);
		        switch (Key.Key)
		        {
			        case ConsoleKey.RightArrow:
				        DisplayWarningMessages();
				        con = false;
				        break;
			        case ConsoleKey.LeftArrow:
				        DisplayTripInfo();
				        con = false;
				        break;
			        case ConsoleKey.UpArrow:
			        case ConsoleKey.DownArrow:
				        isMile = switchBool(isMile);
				        break;
                    case ConsoleKey.Q:
                        EVICSim();
                        break;
		        }
	        } while (con);
        }

        /*
         * this method will display the warning messages and toggle to other menues with the left and right arrow keys
         */
        public static void DisplayWarningMessages()
        {
            Console.WriteLine("\nWarning Messages");	        
	        if (sys.doorAjar)
	        {
		        Console.WriteLine("The Door is ajar");
	        }
	        if (sys.checkEngine)
	        {
		        Console.WriteLine("Check Engine Soon");
	        }
	        if (sys.oilNeedsChanged)
	        {
		        Console.WriteLine("Need Oil Change");
	        }
            ConsoleKeyInfo Key;
            do 
            {
	            Key = Console.ReadKey(true);
	            switch (Key.Key)
	            {
		            case ConsoleKey.RightArrow:
			            DisplayPersonalSettings();
			            break;
		            case ConsoleKey.LeftArrow:
			            DisplaySystemStatus();
			            break;
	            }
            } while (Key.Key != ConsoleKey.LeftArrow || Key.Key != ConsoleKey.RightArrow);

        }

        /*
         * this method will display the personal settings menu and allow the toggling between us and metric units
         * will switch to other menus with left and right arrow keys
         */
        public static void DisplayPersonalSettings()
        {
            ConsoleKeyInfo Key;
            Console.WriteLine("\nPersonal Settings");
            do
            {
                if (sys.metricUnits)
                {
                    Console.WriteLine("Metric Units");
                }
                else
                {
                    Console.WriteLine("U.S. Units");
                }
                Key = Console.ReadKey(true);
                switch (Key.Key)
                {
                    case ConsoleKey.Spacebar:                        
                        sys.changeUnits();
                        break;
                    case ConsoleKey.LeftArrow:
                        DisplayWarningMessages();
                        break;
                    case ConsoleKey.RightArrow:
                        DisplayTempInfo();
                        break;
                }
            } while (Key.Key != ConsoleKey.LeftArrow || Key.Key != ConsoleKey.RightArrow);
        }

        /*
         * this will the display the temp info and toggle between the inside and outside temps.  Will switch menues with the left and right arrow keys
         */
        public static void DisplayTempInfo()
        {
            ConsoleKeyInfo Key;
            Console.WriteLine("\nTemperature Information");
            bool outside = true;
            do
            {                
                if (outside)
                {
                    Console.WriteLine(sys.tempOutside + " F Outside");
                }
                else
                {
                    Console.WriteLine(sys.tempInside + " F Inside");
                }
                Key = Console.ReadKey(true);
                switch (Key.Key)
                {
                    case ConsoleKey.RightArrow:
                        DisplayTripInfo();
                        break;
                    case ConsoleKey.LeftArrow:
                        DisplayPersonalSettings();
                        break;
                    case ConsoleKey.UpArrow:
                    case ConsoleKey.DownArrow:
                        outside = switchBool(outside);
                        break;
                }
            } while (Key.Key != ConsoleKey.RightArrow || Key.Key != ConsoleKey.LeftArrow);
        }

        /*
         * this method will display the trip info and toggle between the trip a and trip b.
         * pressing space bar resets the current trip, and left and right arrow keys will switch menus
         */
        public static void DisplayTripInfo()
        {
            ConsoleKeyInfo Key;
            Console.WriteLine("\nTrip Information");
            bool A = true; 
            do
            {                                                
                if (A)
                {
                    if (sys.metricUnits) 
                    {
                        Console.WriteLine("Trip-A: " + sys.tripA + " km");
                    }
                    else
                    {
                        Console.WriteLine("Trip-A: " + sys.tripA + " mi");
                    }
                }
                else
                {
                    if (sys.metricUnits)
                    {
                        Console.WriteLine("Trip-B: " + sys.tripB + " km");
                    }
                    else
                    {
                        Console.WriteLine("Trip-B: " + sys.tripB + " mi");
                    }
                }
                Key = Console.ReadKey(true);
                switch (Key.Key)
                {
                    case ConsoleKey.LeftArrow:
                        DisplayTempInfo();
                        break;
                    case ConsoleKey.RightArrow:
                        DisplaySystemStatus();
                        break;
                    case ConsoleKey.UpArrow:
                    case ConsoleKey.DownArrow:
                        A = switchBool(A);
                        break;
                    case ConsoleKey.Spacebar:
                        if (A)
                        {
                            sys.tripA = 0;
                        }
                        else
                        {
                            sys.tripB = 0;
                        }
                        break;                    
                }
                
            } while (Key.Key != ConsoleKey.RightArrow || Key.Key != ConsoleKey.LeftArrow);
        }


            //METHODS REGARDING THE EVIC SIMULATOR

        /*
         * this method will start the simulator
         */
        public static void EVICSim()
        {
            bool exit = false;
            while (exit == false)
            {
                DisplayMileage();
                DisplayOptions();
                ConsoleKeyInfo key = Console.ReadKey(true);
                switch (key.Key)
                {
                    case ConsoleKey.D1:
                        DisplayMileage();
                        SystemStatus();
                        break;
                    case ConsoleKey.D2:
                        DisplayMileage();
                        WarningMessages();
                        break;
                    case ConsoleKey.D3:
                        DisplayMileage();
                        break;
                    case ConsoleKey.D4:
                        Console.WriteLine("\nSystem Status\n(For simulator: press Q)");
                        exit = true;
                        break;
                }
            }
        }

        /*
         * this displays the mileage on the odometer
         */
        public static void DisplayMileage()
        {
            if (sys.metricUnits == false) {
                Console.WriteLine("[" + sys.odometer + " mi]");
            }
            else
            {
                Console.WriteLine("[" + sys.odometer + " km]");
            }
        }

        /*
         * displays basic simulator options
         */
        public static void DisplayOptions()
        {
            Console.WriteLine("1) System Status\n2) Warning Messages\n3) Temperature\n4) Quit");
        }

        /*
         * allows the incrementation of the odometer and will change the distance to next oil change
         */
        public static void SystemStatus()
        {
            Console.WriteLine("A)Odometer");
            Console.WriteLine("B)Miles to next Oil Change");
            ConsoleKeyInfo key = Console.ReadKey(true);
            switch (key.Key)
            {
                case ConsoleKey.A:
                    Console.WriteLine("Press Enter to increment the odometer (Press 'e' to exit)");
                    while (!Console.KeyAvailable)
                    {
                        ConsoleKeyInfo Key = Console.ReadKey(true);
                        if (Key.Key == ConsoleKey.Enter)
                        {                            
                            sys.odometer++;
                            sys.oilChange--;
                            Console.WriteLine(sys.odometer.ToString());
                        }
                        else if (Key.Key == ConsoleKey.E)
                        {
                            Console.WriteLine("\n");
                            Main(null);
                        }
                    }
                    break;
                case ConsoleKey.B:                    
                    Console.WriteLine();
                    Console.WriteLine("Miles till oil change " + sys.oilChange);
                    Main(null);
                    return;
            }
        }

        /*
         * this will allow the toggling of certian warning messages
         */
        public static void WarningMessages()
        {
            ConsoleKeyInfo Key;
            do
            {
                Console.WriteLine("Choose a value to toggle\nA)Door Ajar - " + sys.doorAjar.ToString() + "\nB)Check Engine Soon - " + sys.checkEngine.ToString() + "\nC)Oil Change - " + sys.oilNeedsChanged.ToString() + "\nD)Back\n");
                Key = Console.ReadKey(true);
                switch (Key.Key)
                {
                    case ConsoleKey.A:
                        if (sys.doorAjar)
                        {
                            sys.doorAjar = false;
                        }
                        else
                        {
                            sys.doorAjar = true;
                        }
                        break;
                    case ConsoleKey.B:
                        if (sys.checkEngine)
                        {
                            sys.checkEngine = false;
                        }
                        else
                        {
                            sys.checkEngine = true;
                        }
                        break;
                    case ConsoleKey.C:
                        if (sys.oilNeedsChanged)
                        {
                            sys.oilNeedsChanged = false;
                        }
                        else
                        {
                            sys.oilNeedsChanged = true;
                        }
                        break;
                    case ConsoleKey.D:                        
                        break;
                }
            } while (Key.Key != ConsoleKey.D);
        }

        /*
         * this allows the inner and outer temps to be changed
         */
        public static void Temperature()
        {
            ConsoleKeyInfo Key;
            do 
            {
                Console.WriteLine("A) Outside Temperature\nB) Inside Temperature\nC)Back");
                Key = Console.ReadKey(true);
                switch (Key.Key) {
                    case ConsoleKey.A:
                        Console.Write("Please enter a value in Fahrenheit for the Outside temperature: ");
                        sys.tempOutside = Convert.ToInt32(Console.ReadLine());
                        break;
                    case ConsoleKey.B:
                        Console.Write("Please enter a value in Fahrenheit for the Inside temperature: ");
                        sys.tempInside = Convert.ToInt32(Console.ReadLine());
                        break;
                    case ConsoleKey.C:
                        break;
                }
            } while (Key.Key != ConsoleKey.C);
        }

        /*
         * this does just what the title says and switch a bool between true and false
         */
        public static bool switchBool(bool boolToSwitch)
        {
            bool toReturn;
            if (boolToSwitch == true)
            {
                toReturn = false;
            }
            else
            {
                toReturn = true;
            }
            return toReturn;
        }


    }
}