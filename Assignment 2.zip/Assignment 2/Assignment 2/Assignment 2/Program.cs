﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Program
    {
        private Evic sys = new Evic(1566, 33546, false, false, false, false, 148, 130, 385, 100);
        public void Main(string[] args)
        {
            string input = "";              //
            do {
                displayOptions();
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":

                        break;
                    case "2":

                        break;
                    case "3":
                        
                        break;
                    default:
                        break;
                }

            } while (input != "4");


        }

        public void displayMileage()
        {
            if (sys.metricUnits == false) {
                Console.WriteLine("[" + sys.odometer + " mi]\n");
            }
            else
            {
                Console.WriteLine("[" + sys.odometer + " km]\n");
            }
        }

        public void displayOptions()
        {
            Console.WriteLine("1) System Status\n2) Warning Messages\n3) Temperature\n4) Quit");
        }
    }
}
